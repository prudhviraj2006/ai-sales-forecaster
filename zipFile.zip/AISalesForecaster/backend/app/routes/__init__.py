from .upload import router as upload_router
from .forecast import router as forecast_router
from .insights import router as insights_router
from .download import router as download_router
