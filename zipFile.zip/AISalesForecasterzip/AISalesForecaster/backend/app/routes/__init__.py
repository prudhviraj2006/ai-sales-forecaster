from .upload import router as upload_router
from .forecast import router as forecast_router
from .insights import router as insights_router
from .download import router as download_router
from .delete import router as delete_router
from .recommendations import router as recommendations_router
from .chat import router as chat_router
